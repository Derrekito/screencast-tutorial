auto-screencast-term-tutorial
=============================

Automated Screencast for Terminal Based Tutorials Via Script and Other Tools.
